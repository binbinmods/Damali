# 0.2.0

Update for AtO v1.7.22

# 0.1.4

Fixed issue with Stubborn Bully occasionally decreasing enemy damage.

# 0.1.3

Fixed Rupture's Speed Scaling

Swapped which version of Jeer vanishes

Removed Bonus Fury from Yellow Keep Kicking

Reduced Fury gain on Bullish Bovine and Enraged Wrestler

Abuse can now target heroes

Minor tweaks to a couple other cards like Hamstring/Maim

# 0.1.2

Keep Kicking Blue and Yellow have been fixed.

Nerfed the speed gain from Fury.

# 0.1.1

Fixed Keep Kicking

# 0.1.0

Initial concept
