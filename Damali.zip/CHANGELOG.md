# 0.1.2

Keep Kicking Blue and Yellow have been fixed.

Nerfed the speed gain from Fury.

# 0.1.1

Fixed Keep Kicking

# 0.1.0

Initial concept
